// alert("loading")

function addNewHField(){

    let newNode=document.createElement('textarea');
    newNode.classList.add('form-control');
    newNode.classList.add('HField');
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows",1);
    newNode.setAttribute("placeholder",'Enter Here');

    let weOb=document.getElementById('h');
    let hAddButtonOb = document.getElementById("HAddButtton");


    h.insertBefore(newNode, hAddButtonOb);
}

function addNewAField(){
    let newNode=document.createElement('textarea');
    newNode.classList.add('form-control');
    newNode.classList.add('AField');
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows",1);
    newNode.setAttribute("placeholder",'Enter Here');

    let weOb=document.getElementById('a');
    let aAddButtonOb = document.getElementById("AAddButtton");


    a.insertBefore(newNode, aAddButtonOb);
}

function addNewAQField(){
    let newNode=document.createElement('textarea');
    newNode.classList.add('form-control');
    newNode.classList.add('AQField');
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows",1);
    newNode.setAttribute("placeholder",'Enter Here');

    let weOb=document.getElementById('aq');
    let aqAddButtonOb = document.getElementById("AQAddButtton");


    aq.insertBefore(newNode, aqAddButtonOb);
}

function addNewCSField(){
    // console.log("JATIN");
    let newNode=document.createElement('textarea');
    newNode.classList.add('form-control');
    newNode.classList.add('csField');
    newNode.setAttribute("row",3);
    newNode.setAttribute("Placeholder",'Enter Here');

    let csOb = document.getElementById("we");
    let CSAddButton=document.getElementById('CSAddButton');

    cs.insertBefore(newNode, csAddButtonOb);
}


// *************************************** Generate Resume ******************************************************

function generateCV()
{
    let nameField=document.getElementById("nameField").value;
    let nameT1=document.getElementById("nameT1");
    nameT1.innerHTML=nameField;


    document.getElementById("nameT2").innerHTML=document.getElementById("nameField").value;

    document.getElementById("DOBT").innerHTML=document.getElementById("birthField").value;

    document.getElementById("emailT").innerHTML=document.getElementById("emailField").value;

    document.getElementById("phoneT").innerHTML=document.getElementById("contactField").value;

    document.getElementById("addressT").innerHTML=document.getElementById("addressField").value;

    document.getElementById("educationT").innerHTML=document.getElementById("EducationField").value;

                                 // Professional skills 
    document.getElementById("oT").innerHTML=document.getElementById("objectiveField").value;

    document.getElementById("weT").innerHTML=document.getElementById("weField").value;


     let wes = document.getElementsByClassName("aqField");

     let str="";

    for(let a of wes) {
        str = str + `<li> ${a.value} </li>`;
    }
   document.getElementById("psT").innerHTML = str;


    document.getElementById("csT").innerHTML=document.getElementById("csField").value;

    document.getElementById("AT").innerHTML=document.getElementById("AchField").value;

    document.getElementById("hT").innerHTML=document.getElementById("hobField").value;



    document.getElementById("cv-form").style.display='none'
    document.getElementById('cv-template').style.display='block'


}



// *************************************************************************








