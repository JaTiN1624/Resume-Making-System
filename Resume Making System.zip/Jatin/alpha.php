<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <link rel="stylesheet" href="wStyle.css" class="">
    <title>Redirection </title>
  </head>
  <body>
        <!-- ******************** START *************************** -->


<section>
 <div class="  container mt-5" id="cv-form">
     <h1 class="text-center my-3">FILL UP YOUR DETAILS HERE</h1><hr>
     <div class="row">
         <div class="col-md-6">
             <!-- first col  -->
             <h4>Personal information</h4>

             <div class="form-group">
                 <label for="nameField">Full Name</label>
                 <input type="text" id="nameField" class="form-control" placeholder="Enter Your Full Name" required autocomplete="off">
             </div>

             <div class="form-group my-2">
                  <label for="birthField">Date_Of_Birth</label>
                  <input type="date" id="birthField" class="form-control"  placeholder="Enter Your DOB" required autocomplete="off">
             </div>

 
             <div class="form-group">
                   <label for="email">Email Your Email:</label>
                   <input type="email" id="emailField" class="form-control" name="email" placeholder="Enter Your Email" required autocomplete="off">    
             </div>


             <div class="form-group my-2">
                   <label for="contactField">Your Contact</label>
                   <input type="tel" id="contactField" class="form-control" name="phone" placeholder="Enter Your Contact" required autocomplete="off">
             </div>

        
             <div class="form-group">
                    <label for="addressField">Address</label>
                    <textarea  id="addressField" class="form-control" placeholder="Enter Your Address" rows="2" required autocomplete="off"></textarea>
             </div>

             <div class="form-group mt-2">
                    <label for="cityField">Education</label>
                    <input type="list" id="EducationField" class="form-control" placeholder="Enter Here" required autocomplete="off">
             </div>
             </form>
     </div>
         <div class="col-md-6">
             <!-- second col  -->
             <h4>Professional Information</h4>

             <div class="form-group my-2">
               <label for="objectivesField">Objectives</label>
               <textarea id="objectiveField" class="form-control" placeholder="Enter Here" rows="1"></textarea>
             </div>

             <div class="form-group">
               <label for="addressField">Work Experiance</label>
                <textarea  id="weField"class="form-control wField" placeholder="Work Experiance" rows="1"></textarea>
             </div>

             <div class="form-group my-2 "id="aq">
                 <label for="">Professional Skills</label>
                 <textarea   class="form-control  aqField" placeholder="Enter Here " rows="1"></textarea>
             </div>
             <div class="container text-center mt-2" id="AQAdddNewButton">
                  <button onclick="addNewAQField()" class="btn btn-primary btn-sm" >Add</button>
             </div>

             <div class="form-group my-2" id="a">
                <label for="">Complementary Skills</label>
                <textarea  id="csField" class="form-control aField" placeholder="Enter Here" rows="1"></textarea>
             </div>
            <div class="container text-center mt-2 " id="AAddButton">
                 <button onclick="addNewAField()" class="btn btn-primary btn-sm" >Add</button>
            </div>

            <div class="form-group mt-2" id="cs">
                 <label for="">Achievements</label>
                 <textarea id="AchField" class="form-control csField" placeholder="Achievements" rows="1"></textarea>
            </div>

            <div class="form-group my-2" id="h">
                 <label for="">Hobbies</label>
                 <textarea  id="hobField"class="form-control  HField" placeholder="Enter Here" rows="1"  ></textarea>
             </div>  
             <div class="container text-center mt-2" id="HAddButton">
                 <button onclick="addNewHField()" class="btn btn-primary btn-sm">Add</button>
             </div>    
            
             
            </div>
            <div class="jatin text-center">
      
                 <button  onclick="generateCV()" class="btn btn-lg mt-3 btn-primary">
               <a href="#cv-template">
                      Create Resume 
                      </a>
                 </button>
            </div>
     </div>
 </div>    
</section>

<!-- ********************************************* Resume Template **************************************************  -->


<div class="container mt-5" id="cv-template">
    <div class="row">
        <div class="col-md-4 py-5 background">
            <!-- First col  -->
            <div class="container-d">
                <p id="nameT1" id=""class="heading">Resume builder</p>
              <div class="para">
                <div>
                <i class="fa fa-calendar fa-fw "></i> <p id="DOBT"> 06/12/2001</p>
                </div>
                <div>
                <i class="fa fa-envelope fa-fw my-2"></i>
                <p id="emailT" > example@gmail.com</p>
                </div>

               <div>
                 <i class="fa fa-phone fa-fw " ></i>
                <p id="phoneT"> 1224435534</p>   
               </div>
               <div>
               <i class="fa fa-home fa-fw "></i>
                <p id="addressT">Address</p><hr>
               </div>
             </div>
                
                <h4><i class="fa fa-briefcase fa-fw "></i>Education</h4>
                <p id="educationT"> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem, totam.</p><hr>
            </div>
        </div>


        <div class="col-md-8 py-4">
            <!-- second col  -->
            <h1 id="nameT2" class="text-center" style=font-weight:980>Resume builder</h1>

            <div class="card ">
                <div class="card-header background">
                    <h3><i class="fa fa-asterisk fa-fw "></i> Objective</h3>
                </div>
                <div id="oT" class="card-body">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident delectus sequi ab distinctio odio repudiandae earum eveniet voluptate cupiditate at.

                </div>
            </div>
            <div class="card mt-4 ">
                <div class="card-header background">
                    <h3><i class="fa fa-suitcase fa-fw "></i> Work Experiance</h3>
                </div>
                <div id="weT" class="card-body">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident delectus sequi ab distinctio odio repudiandae earum eveniet voluptate cupiditate at.
                </div>
            </div>
            <div class="card mt-4 ">
                <div class="card-header background">
                    <h3><i class="fa fa-certificate fa-fw "></i> Professional Skills</h3>
                </div>
                <div class="card-body">
                   <ul id="psT">
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                   </ul>
                </div>
            </div>
            <div class="card mt-4 ">
                <div class="card-header background">
                    <h3><i class="fa fa-certificate fa-fw "></i> Complementry Skills</h3>
                </div>
                <div class="card-body">
                   <ul id="csT">
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                       <li>
                           Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam?
                       </li>
                   </ul>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header background">
                    <h3><i  class="fa fa-trophy fa-fw "></i> Achievements</h3>
                </div>
                <div  id="AT" class="card-body">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident delectus sequi ab distinctio odio repudiandae earum eveniet voluptate cupiditate at.

                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header background">
                  <h3><i class="fab fa-hornbill"></i> Hobbies</h3>
                </div>
                <div id="hT" class="card-body">
                   <ul>
                       <li >
                         Lorem ipsum dolor sit amet.
                       </li>
                       <li>
                         Lorem ipsum dolor sit amet.
                       </li>
                   </ul>
                </div>
            </div>

            <div class="container mt-3 text-center">
                  <button onclick="window.print()" id="knameT1" class="btn background">
                      Print Resume
                  
                  </button>
            </div>  


            


        </div>
    </div>
</div>











<script src="script.js"></script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>