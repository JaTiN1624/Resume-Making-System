
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="stylee.css" class="css">
</head>
<body>
     <div class="header" id="topheader">
     <nav class="navbar navbar-expand-lg navbar-dark fixed-top ">
         <div class="container text-uppercase p-2">
             <a class="navbar-brand font-weight-bold text-white" href="#">RESUDER</a>
             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                 <span class="navbar-toggler-icon"></span>
                
                </button>
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto text-uppercase">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Home</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="login.php">log In </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="register.php">Sign Up</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="">About Us</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="#contactid">Contact Us</a>
                        </li>
                       
                    </ul>
                    
                </div>
            </div>
          </nav>
          <section class="header-section">
              <div class="center-div">
                  <h1 class="font-weight-bold">
                  THE ONLINE RESUME BUILDER
                  </h1>
                  <p> Creating a Professional Resume and Cover Letter <br> Has Never Been So Easy</p>
                  <div class="header-button">
                      <a href="alpha.php">Create Your Resume </a>
                  </div>
              </div>
          </section>
        </div>
        
<!-- ************************* Header part End******************************** -->

<!-- ****************************************** Service Center Start *************************** -->
 
<section class="header-service">
    <h1>3 EASY STEPS TO CREATE YOUR PERFECT RESUME</h1>
    <div class="container">

        <div class="row my-5 ">
           <div class="extra-div col-lg-4 col-md-4 col-12">
            <a href="#">
               <i class="fa-4x fa fa-file-text" aria-hidden="true"></i>
            </a>  
             <h3>CHOOSE  YOUR RESUME TEMPLATE</h3>
             <h7>Your professional resume templates are designed strictly following all industry guidlines and best practices emplpoyers are looking for.</h7>
             
           </div>
           <div class="extra-div col-lg-4 col-md-4 col-12">
            <a href="#">
            <i class="fa-4x fa fa-pencil-square-o" aria-hidden="true"></i>
            </a>  
             <h3>SHOW WHAT YOU'RE MADE OF</h3>
             <h7>Not finding the right words to showcase yourself? We've added thousands of pre-written examples and resume samples.</h7>
             
           </div>
           <div class="extra-div col-lg-4 col-md-4 col-12">
            <a href="#">
            <i class="fa-4x fa fa-print" aria-hidden="true"></i>
            </a>  
             <h3>DOWNLOAD YOUR RESUME</h3>
             <h7>Start impressing employers.Download your awesome resume and land the job you are looking for,effortlessly.</h7>
             
           </div>
        </div>
    </div>
</section>

<!-- ****************************************** Service Center End***************************-->

<!-- ************************************************ Template Example Start**************************8 -->
<section class="happyclients">
    <div class="container heading text-center">
        <h1 class="text-center font-weight-bold text-uppercase">Resume template examples</h1>
        <p class="text-capitalize pt-1"></p>
    </div>
    <div id="demo" class="carousel slide" data-ride="carousel">

<!-- Indicators -->
<ul class="carousel-indicators">
  <li data-target="#demo" data-slide-to="0" class="active"></li>
  <li data-target="#demo" data-slide-to="1"></li>
  <li data-target="#demo" data-slide-to="2"></li>
</ul>

<!-- The slideshow -->
<div class="carousel-inner">
  <div class="carousel-item active">
   <div class="row">
       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>


   </div>
  </div>
  <div class="carousel-item">
  <div class="carousel-item active">
   <div class="row">
       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php">CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>
  </div>
  <div class="carousel-item">
   <div class="carousel-item active">
   <div class="row">
       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php">CREATE NOW</a></h5>
           </div>
       </div>

       <div class="col-lg-4 col-md-4 col-12">
           <div class="box">
               <a href="#">
                   <img src="photo.jpg" alt="image is not load" class="img-fluid img-thumbnail">
               </a>
               <h5><a href="alpha.php"> CREATE NOW</a></h5>
           </div>
       </div>
  </div>
</div>

<!-- Left and right controls -->
<a class="carousel-control-prev" href="#demo" data-slide="prev">
  <span class="carousel-control-prev-icon"></span>
</a>
<a class="carousel-control-next" href="#demo" data-slide="next">
  <span class="carousel-control-next-icon"></span>
</a>

</div>
</section>


<!-- ************************************************ Template Example Start**************************8 -->

<!-- ************************************************** Contact us start********************************** -->
 <section class="contactus" id="contactid">
   <div class="container-headings ">
      <h1 class="text-center font-weight-bold">CONTACT US</h1>
       <p>We're Here To Help And Answer Any Question You Might Have. We Look Forward To Hearing From You🙂</p>
       <div class="container">
           <div class="row">
               <div class="col-lg-8 col-md-8 col-10 offset-lg-2 offset-md-2 offset-1">
               
               <form action="/action_page.php">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Enter Your Name" id="name" required autocomplete="off">
                    </div>
                    
                    <div class="form-group">                      
                        <input type="email" class="form-control" placeholder="Enter Your Email" id="email" required autocomplete="off">
                    </div>
                    
                    <div class="form-group">                       
                        <input type="text" class="form-control" placeholder="Enter Your number" id="mobile" required autocomplete="off">
                    </div>
                    <div class="form-group">
                      <textarea class="form-control" placeholder="Enter Your Message" rows="3" id="comment"></textarea>
                    </div>
                    <div class="d-flex justify-content-center form-button">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                 </form>
               </div>
           </div>
       </div>
   </div>
 </section>




<!-- ************************************************** Contact us end************************************* -->

<!-- ************************************************** Footer section start************************************* -->
<footer class="footersection" id="footerdiv">
    <div class="container">
        <div class="row">
            <div class="col-log-4 col-md-6 col-12  footer-div text-center para">
                <div>
                    <h3>
                        ABOUT RESUDER
                    </h3>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus dignissimos dolorum quam, at nihil quisquam quos rerum magnam ducimus quas libero nobis quod.
                    </p>
                </div>
            </div>

            <div class="col-log-4 col-md-6 col-12 footer-div text-center">
                <div>
                    <h3>
                        NAVIGATION LINKS
                    </h3>
                   <li><a href="#">HOME</a></li>
                   <li><a href="#">SIGN IN</a></li>
                   <li><a href="#">SIGN UP</a></li>
                   <li><a href="#">ABOUT US</a></li>
                   <li><a href="#">CONTACT US</a></li>
                </div>
            </div>
        </div>
        <div class="mt-5 text-center ">
            <p>copyright © All right reserved | This website is usefull for You🙂</p>
        </div>
        

        <div class="scrolltop float-right">
            <i class="fa fa-arrow-up" onclick="topFunction()" id="myBtn"></i>
        </div>
    </div>
</footer>

<!-- ************************************************** footer section end************************************* -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    $('.count').counterUp({
        delay:10,
        time:3000
    })
      //Get the button //

    mybutton = document.getElementById("myBtn");

    // when the user scroll down 20px from the top of the document, show the button 
    window.onscroll=function() {scrollFunction()};

    function scrollFunction() {
         if(document.body.scrollTop > 20 || document.documentElement.scrollTop > 20 ) {
             myButton.style.display = "block";
         }
         else{
             mybutton.style.display="none";
         }
    } 

    // when the user clicks on the button, scroll to the top of the document 
    function topFunction(){
        document.body.scrollTop = 0; // for safari
        document.documentElement.scrollTop = 0; // for choose, firefox, IE and opera
    }
  </script>
</body>
</html>

<!-- *************************************  CODE END************************************** -->





                   <!-- temp code  -->

                   <!-- reg php -->
                   <?php

include 'connection.php';

if(isset($_POST['submit'])){

    // get data from user 
    $name = $_POST['name'];
    $email = $_POST['username'];
    $number = $_POST['mobile'];
    $password= $_POST['password'];
    $con_password = $_POST['confirm_password'];


    // inserting values into databse.
    $insertquery = "insert into ehealth(id, Name, password, mobile) values('$email','$name','$password','$number')";

   $res = mysqli_query($con, $insertquery);

    if($res){
        ?>
        <script>
            alert("Data inserted successfully");
        </script>
        <?php
    }else{
        ?>
        <script>
            alert("Data not inserted");
        </script>
        <?php
    }
}
?>



                  <!-- log php  -->
                  <?php
    // this script will handle login
    session_start();

    // check the user is already logged in 
    if(isset($_SESSION['username']))
    {
        header("location:home.php");
        exit;
    }
    require_once "config.php";

    $username = $password = "";
    $err = "";

    // if request method is post
    if($_SERVER['REQUEST_METHOD'] == "POST"){
        if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
        {
            $err = "Please enter usernamane and password";

        }
        else{
            $username = trim($_POST['username']);
            $password = trim($_['password']);
        }

        if(empty($err))
        {
            $sql ="SELECT id, username, password FROM users WHERE username";
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = $username;

            // try to execute this statement
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    mysqli_stmt_bind_result($stmt,$id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if(password_verify($password, $hashed_password))
                        {
                            // this means the password is correct allow the user to login
                            session_start();
                            $_SESSION["username"] = $username;
                            $_SESSION["id"] = $id;
                            $_SESSION["loggedin"] =true;

                            // redirect to welcome page
                            header("location:home.php");
                        }
                    }

                }
            }
        }
    }
?>
