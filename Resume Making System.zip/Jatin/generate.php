<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
     <link rel="stylesheet" href="Tstyle.css">
    <title>  Template</title>
  </head>
  <body>
    <div class="container"  id="cv-form">
      <div class="row">
        <div class="col-md-4 text-center py-5 background">
           <!-- First column -->
           <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxATDxUQEA8QEhISEBAQDxAQEBAPEBANFRUWFhYSExMYHCggGBolGxUVITEhJSktLi4uFx8zODMsNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIANIA8AMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQUDBAYCB//EADQQAAIBAgMFBgYCAgMBAAAAAAABAgMRBCExBUFRcZESMkJhgaEiUrHB0eFi8CPxU3KSM//EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD7UAAAAAAAAAAAAAAHipUjHvSS5uwHsGnPaVNaXfJW+phltXhDq/0BZAqntV/KvcLar+Ve4FqCujtVb49H+jPTx9N72ua/AG0DzCaejT5M9AAAAAAAAAAAAAAAAAAAAAAAA81JqKvJ2S3sD0a+IxkIZN3fyrN+vAr8XtGUsoXiuPif4NEDcr7RnLT4V5a9TTb3sAAAAAAAAAD1Go1ozdobSku9mvfqaAA6ChiYy0efB6mY5qMmtCxwm0d0+u8C0BEZJq6zRIAAAAAAAAAAAAAAAPFWoopybslqBFetGEe1L04t8EUeKxMpu703R3L9kYrEOcrvTwrgjEAAAAAmEG3ZK7eiQEEwg3om+SbLXDbMSznm/l8K/JvxikrJJLgskBQrBVX4H6uK+rEsFVXgfo0/oy/AHNTi1lJNc00QdLKKas0muDV0V+K2YnnTyfyvuvlwAqgTKLTs1ZrVMgAAANrB4xxfkXNOopK6OcNrBYpwfkBeAiMk1daMkAAAAAAAAAAABS7SxXal2V3YvrLib+0sR2IZd6WS8lvf94lGBIAAAACYRbdlqy8weFUFxk9X9l5GtsnD+N8l92WQAAAAAAAAGrjsIprhJd1/Z+RRtNOzyaya4M6YqtsULNVFv+GXPc/75AVwAAAACx2Zic+y/QtTmouzuX2DrdqKe9ZMDOAAAAAAAAAYcXV7NOUt6WXN5ICn2hW7VR8I/CvTV9TXIRIAAACYrMg90F8SAv6ELRS8vcyAAAAAAAAAADDi6fapyX8Xbms0ZgBzCJIRIAAADd2XWtK25mkTTlZpgdKDxRneKfFe57AAAAAABXbZn8MY8ZX9F/ssSn2xL/Ilwj9W/wAAaIAAAAAeqL+JHkJgdKnvJMGCqdqC8sjOAAAAAAAAAPM5WTfBN9D0ae1KvZptb5fCuW/2+oFIiSCQAAAAAC62XO8LcGbhV7Hlqi0AAAAAABR7Uf8AlfKP0Lwo9qf/AFfKP0A1QAAAAAAgDe2biey7PRlycwmWeAx3hl6MC0BCZIAAAACJSSV27Jat6AGyix2I7c7rurKP5MuPx3a+GPd3vfL9GiBIIJAAAAAAN/ZD+P0ZblPsnv8Aoy4AAAAAABTbXj/kT4wX1ZclZtqHdl5uPXNfRgVgAAAGTD0XKSit4HvC4WU3lkt8nov2W1DA04+HtPjLP2M1KmopRWi/tz2BrYzBxmuDXdfDyfkUtalKDtJWfs/NM6M8VaUZK0kmv7oBS4fGyjvuuBv0tpReqa9zBX2U9YO/8Za+jNKpQnHvQkvO111QF2sZT+ZdGRLG014uibKC4uBb1dqRXdi3zyRXYjEzn3nluSyS9CKeHnLuwk/O1l1Zu0NlvWb9I69QNGjRlJ2ir/RLiy7wuFjBW1b7z4+XIy0qcYq0Ukj2Bq18BTlu7L4xy9tGVGKw0oOzzT0ktH+GdCY61JSi4y0fs+KA50HqrTcZOL1T6rczyAAAFjsePxN+X4LU0NkQ+Fvi7f3qb4AAAAAANbaNLtUpcV8S9P1c2QBzBJkxNLsTceDy/wCr0MYAt9lUbR7W95Ll/foVMFdnRUoWilwXuB7AAAAAAABDit6XQKK3JdCQAAAAAAAABWbZo5Ka3fDLk9Pf6lYdFiKfahKPFO3Pd7nOICQkDPgaPamlu38gLnBwtBLyv1MwAAAAAAAAAFdteheKmtY5P/r+vuVJ0zW5+vIoMXh3CfZ3POL8gJwML1FzRfnN05tO6L3CYhTj57wM4AAAAAAAAAAAAAAAAAAHO4mNpyXCTtyuXGPxfYVl3nouHmyjf++YAudl0LR7T1lpyK7A4fty8lm+RepASAAAAAAAAAABgxeHU42eusXwZnAHNTg03GSs1qj3QrOLui4x2DU1dZSWj4+TKScWnZqzWqAvsNiVNZa70Zzm6dRxd0y2wu0E8pZPiBvAhMkAAAAAAAAAARJpK7dlvb0Ak1cZjFBW1luX3ZrYvae6n/6enoisbu7t3b1b1AmpNybk3dvUmlTcmkldsinBt2Su3oi8wWEUFxk9X9kB7w1BQjZer4szAAAAAAAAAAAAAAAA18XhIzWeTWklqvyjYAHO4jDyg7SWW6S0ZjOllFNWaTT1TzRW4nZe+m7fxenowNShjJR0eXA36O0ovvK3IqqtOUXaUWuej5PeeAOjhWi9JL7mQ5pSZ7jXktJNcm0B0QKFY2p8z6kPGVPnl1AvzFUxEI6yXK930RQzrSesm+bbPAFrW2qvBG/nLJdCur4ic+87+WiXoYz1SpSk7RTfLdze4DyZcNhpTfwrLe3ojfw2y99R3/itPVljGKSskkloloBhwuFjBZZvfJ6v8IzgAAAAAAAAAAAAAAAAAAAAAAESimrNJrg80adXZlN6Xi/4vLozdAFRU2VPwyi+d4/kwywFVeC/Jx/JegDnnhan/HLpcLC1P+OXRnQgChjgKr8FubivuZ6eypeKUVyvItwBpUtm01reXPTojcjFJWSSXBZIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/9k=" alt="Images is not loading"
           class="img-fluid myimg"
           >
           <div class="container ">
               <p id="nameT1">Albert Einstein</p>
               <p id="DOBT">23-04-2000</p>
               <p id="emailT">xyz@gmail.com</p>
               <p id="contactT">5846924782,6598745325</p>
               <p id="addressT">NIT Polytechnic,mahurzari</p>
               <p id="cityT">Nagpur</p><hr>
            
            </div>
            <div class="education">
                <h4>Education</h4>
                <p>
                   Lorem ipsum dolor sit amet consectetur.
                </p><hr>
              
            </div>
        </div>
        
    <div class="col-md-8">
          <!-- Second Column -->
          <h1 id="nameT2" class="text-center" style="font-weight:980 "> Albert Einstein</h1>
    
         <!-- Objectives card -->

         <div class="card mt-4">
             <div class="card-header background">
                 <h3>Objectives</h3>
             </div>
             <div class="card-body">
                 <p id="objectiveT">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aliquam dicta asperiores, veniam quae consectetur exercitationem dolores commodi ut. Impedit voluptatibus qui consectetur dicta incidunt aspernatur. Sed nihil similique, culpa magni voluptatum quae eveniet.</p>
             </div>
         </div>

                                           <!-- Work Experiance -->

         <div class="card-header mt-4 background">
             <h3>Work Experiance</h3>
            </div>
            <div class="card-body">
                <p id="workT">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aliquam dicta asperiores, veniam quae consectetur exercitationem dolores commodi ut. Impedit voluptatibus qui consectetur dicta incidunt aspernatur. Sed nihil similique, culpa magni voluptatum quae eveniet.</p>
            </div>

        
                                         <!--  Professional skills -->

        <div class="card mt-4">
             <div class="card-header background">
                 <h3>Professional Skills</h3>
             </div>
             <div class="card-body">
                 <ul id="PrT">
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                 </ul>
             </div>
         </div>
                          <!-- Complementary skills -->
         <div class="card mt-4">
             <div class="card-header background">
                 <h3>Complementary Skills</h3>
             </div>
             <div class="card-body">
                 <ul id="cmT">
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                 </ul>
             </div>
         </div>
        
                                   <!-- Achievements -->

            <div class="card-header mt-4 background">
             <h3>Achievements</h3>
            </div>
            <div class="card-body">
                <p id="AchievementT">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aliquam dicta asperiores, veniam quae consectetur exercitationem dolores commodi ut. Impedit voluptatibus qui consectetur dicta incidunt aspernatur. Sed nihil similique, culpa magni voluptatum quae eveniet.</p>
            </div>

         
 
                                <!-- Hobbies -->

         <div class="card mt-4">
             <div class="card-header background">
                 <h3>Hobbies</h3>
             </div>
             <div class="card-body">
                 <ul id="HobbiesT">
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                     <li>
                         Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, incidunt.
                     </li>
                 </ul>
             </div>
         </div>

                           <!-- Print Button  -->
         <div class="container   mt-4 text-center  ">
           <button onclick="printCV()" class="btn "> PRINT</button>
         </div>
     </div>
  </div>
    
    </div>
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="script.js"></script>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>