<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <link rel="stylesheet" href="Style.css" class="">
    <title>Resume Template</title>
  </head>
  <body>
        <!-- ******************** START *************************** -->

<!-- ******************** NAVBAR START ********************************************** -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid text-center">
    <a class="navbar-brand" href="project.php">Webuls</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
      <li class="nav-item">
          <a class="nav-link" href="../project.php">HOME</a>
        </li>
         
        <li class="nav-item">
          <a class="nav-link" href="../signin.php">SIGN IN</a>
        </li>
         
        <li class="nav-item">
          <a class="nav-link" href="../signup.php">SIGN UP</a>
        </li>
      </ul>
    </div>
</nav>
<!-- ******************** NAVBAR END ********************************************** -->

<!-- ******************** HTML CODE START ********************************************** -->

 <div class="container">
     <h1 class="text-center my-3">FILL UP YOUR DETAILS HERE</h1><hr>
     
     <div class="row">
       <div class="col-md-6">
           <!-- First column -->
         <h4>PERSONAL INFORMATION</h4><br>
         
         <form action="/action.php">
         <div class="form-group " >
           <label for="">Full Name</label>
           <input type="name" id="nameField" class="form-control" placeholder="Enter Your Full Name" required autocomplete="off">
         </div>
         <form action="/action.php">
         <div class="form-group my-2">
           <label for="birthField">Date_Of_Birth</label>
           <input type="date" id="birthField" class="form-control" name="birthday" placeholder="Enter Your DOB" required autocomplete="off">
       

         </div>
         <form action="/action.php">
         <div class="form-group">
           <label for="email">Email Your Email:</label>
           <input type="email" id="emailField" class="form-control" name="email" placeholder="Enter Your Email" required autocomplete="off">
        
         </div>
         <form action="/action.php">
         <div class="form-group my-2">
           <label for="contactField">Your Contact</label>
           <input type="tel" id="contactField" class="form-control" name="phone" placeholder="Enter Your Contact" required autocomplete="off">
         </div>
         <form action="/action.php">
         <div class="form-group">
           <label for="addressField">Address</label>
           <textarea  id="addressField" class="form-control" placeholder="Enter Your Address" rows="2" required autocomplete="off"></textarea>
         </div>
         <form action="/action.php">
         <div class="form-group mt-2">
           <label for="cityField">City</label>
           <input type="text" id="cityField" class="form-control" placeholder="Enter Your City" required autocomplete="off">
         </div>
         <form action="/action.php">
         <div class="form-group mt-2">
           <label for="cityField">Education</label>
           <input type="list" id="EducationField" class="form-control" placeholder="Enter Here" required autocomplete="off">
         </div>

       </div>


       <div class="col-md-6">
              <!-- Second column -->

          <h4>PROFESSIONAL INFORMATION</h4><br>

          <!-- ObjectiveField -->
          <div class="form-group my-2">
            <label for="objectivesField">Objectives</label>
            <textarea id="objectiveField" class="form-control" placeholder="Enter Here" rows="1"></textarea>
          </div>

          <div class="form-group">
           <label for="addressField">Work Experiance</label>
           <textarea  class="form-control weField" placeholder="Work Experiance" rows="1"></textarea>
         </div>
         
         <!-- Professional Skills Field -->
         <div class="form-group my-2 "id="aq">
           <label for="">Professional Skills</label>
           <textarea  class="form-control  aqField" placeholder="Enter Here " rows="1"></textarea>
          </div>
          <div class="container text-center mt-2" id="AQAdddNewButton">
            <button onclick="addNewAQField()" class="btn btn-primary btn-sm" >Add</button>
          </div>

          <!-- Comoplementry Field -->
          <div class="form-group my-2" id="a">
            <label for="">Complementary Skills</label>
            <textarea  class="form-control aField" placeholder="Enter Here" rows="1"></textarea>
          </div>
          <div class="container text-center mt-2 " id="AAddButton">
           <button onclick="addNewAField()" class="btn btn-primary btn-sm" >Add</button>
          </div>
          
          <!-- Achievement Field -->
          
          <div class="form-group mt-2" id="cs">
          <label for="">Achievements</label>
          <textarea  class="form-control csField" placeholder="Achievements" rows="1"></textarea>
          </div>
                                  <!-- Hobbies Field -->
         <div class="form-group my-2" id="h">
           <label for="">Hobbies</label>
           <textarea  class="form-control  HField" placeholder="Enter Here" rows="1"  ></textarea>
         </div>

         <div class="container text-center mt-2" id="HAddButton">
          <button onclick="addNewHField()" class="btn btn-primary btn-sm">Add</button>
         </div>
       </div>
     </div>
  </div>
                       <!-- Create Button -->
  <div class="jatin text-center">
     
     <button  onclick="generateCV()" class="btn btn-lg mt-3 btn-primary">
     <a href="generate.php">
       Create Resume 
      </a>
      </button>
  </div>

<!-- ********************************************************************************************************************************************* -->




      <script src="script.js"></script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>